export interface PagedRoleResultRequestDto extends PagedFilterAndSortedRequest  {
    keyword: string
}
