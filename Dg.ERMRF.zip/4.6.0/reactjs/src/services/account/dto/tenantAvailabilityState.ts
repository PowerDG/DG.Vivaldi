enum TenantAvailabilityState {
  Available = 1,
  InActive,
  NotFound,
}

export default TenantAvailabilityState;
