interface PagedFilterAndSortedRequest {
  maxResultCount: number;
  skipCount: number;
}
