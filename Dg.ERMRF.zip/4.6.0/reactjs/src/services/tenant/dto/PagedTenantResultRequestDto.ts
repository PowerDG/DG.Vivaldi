export interface PagedTenantResultRequestDto extends PagedFilterAndSortedRequest  {
    keyword: string
}
