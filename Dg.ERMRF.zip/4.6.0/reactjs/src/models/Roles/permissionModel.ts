class PermissionModel {
  name: string;
  displayName: string;
  description?: any;
}

export default PermissionModel;
