

using System.Collections.Generic;
using Abp.Application.Services.Dto;
using Dg.ERM.Authorization.ExtendInfos;

namespace Dg.ERM.Authorization.ExtendInfos.Dtos
{
    public class GetExtendInfoForEditOutput
    {

        public ExtendInfoEditDto ExtendInfo { get; set; }

    }
}