

using System.Collections.Generic;
using Abp.Application.Services.Dto;
using DG.ERM.Products;

namespace DG.ERM.Products.Dtos
{
    public class GetProductForEditOutput
    {

        public ProductEditDto Product { get; set; }

    }
}